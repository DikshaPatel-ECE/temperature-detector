#include "DHT.h"

#define DHTPIN 2       // Data pin connected to DHT11
#define DHTTYPE DHT11  // Sensor type

DHT dht(DHTPIN, DHTTYPE);

void setup() {
  Serial.begin(9600);
  dht.begin();
}

void loop() {
  float tempC = dht.readTemperature();   // Celsius
  float hum = dht.readHumidity();        // Humidity

  if (isnan(tempC) || isnan(hum)) {
    Serial.println("Sensor reading failed!");
    return;
  }

  Serial.print("Temperature: ");
  Serial.print(tempC);
  Serial.println(" °C");

  Serial.print("Humidity: ");
  Serial.print(hum);
  Serial.println(" %");

  delay(2000);
}
